# Roamly — Personalized Travel Itinerary Planner

A full-stack starter project for personalized trip planning, built with **React + Vite**, **FastAPI**, and optional **Supabase** and **OpenAI-compatible AI generation**.

## Features
- SaaS-style travel dashboard
- Trip builder: destination, dates, budget, travel style, interests, travelers
- Day-by-day itinerary cards
- Save and view trips (local browser storage demo)
- FastAPI endpoint for itinerary generation
- Optional OpenAI API integration using an environment variable
- Optional Supabase persistence setup
- Friendly fallback itinerary if no AI key is configured

> This is a project starter, not a deployed public website. You can run it locally and push the source files to GitHub. API-backed AI and Supabase features need your own keys/configuration.

## Project structure

```text
roamly-travel-planner/
├── frontend/              # React + Vite app
├── backend/               # FastAPI API
├── .gitignore
└── README.md
```

## 1. Requirements
- Node.js 18+ and npm
- Python 3.10+
- Optional: Supabase project
- Optional: OpenAI API key

## 2. Run the backend

Open Terminal in the project folder:

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate      # macOS/Linux
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

API docs: http://127.0.0.1:8000/docs

If you don't add an AI key, the backend returns a demo itinerary. To enable AI generation, add your key and model in `backend/.env`.

## 3. Run the frontend

Open a second Terminal window:

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Open the URL Vite prints, normally http://localhost:5173.

The frontend calls the FastAPI backend at `http://127.0.0.1:8000`. Keep both terminals running while using the full-stack version.

## 4. Optional Supabase setup
1. Create a project at https://supabase.com.
2. In the SQL editor, run `backend/supabase_schema.sql`.
3. Copy your project URL and service role key into `backend/.env`.
4. **Never put the service role key in frontend code or commit it to GitHub.**

Supabase persistence is an optional backend integration; the demo frontend keeps saved trips in local browser storage so it can be tried without credentials.

## 5. Push to GitHub

Create an empty repository on GitHub, then from the project root:

```bash
git init
git add .
git commit -m "Initial Roamly travel planner project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your repository's URL. Do not commit `.env` files, API keys, passwords, or Supabase service-role keys.

## API endpoint
`POST /api/itinerary`

Example request:

```json
{
  "destination": "Udaipur, Rajasthan",
  "start_date": "2026-11-14",
  "duration_days": 3,
  "budget": 12000,
  "travel_style": "Balanced",
  "travellers": "Couple",
  "interests": ["Sightseeing", "Food"]
}
```

## Disclaimer
The generated plan is a planning suggestion. Check current opening hours, transport options, prices, and reservations before travelling.
