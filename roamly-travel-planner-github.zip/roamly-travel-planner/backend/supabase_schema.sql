-- Optional database schema for storing user trips.
-- Run this in Supabase SQL Editor. Enable Row Level Security before production use.
create table if not exists public.trips (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  destination text not null,
  start_date date,
  duration_days integer not null check (duration_days between 1 and 14),
  budget integer not null default 0,
  travel_style text not null default 'Balanced',
  travellers text not null default 'Solo traveler',
  interests text[] not null default '{}',
  itinerary jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.trips enable row level security;

create policy "Users can read their own trips"
on public.trips for select
using (auth.uid() = user_id);

create policy "Users can insert their own trips"
on public.trips for insert
with check (auth.uid() = user_id);

create policy "Users can update their own trips"
on public.trips for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create policy "Users can delete their own trips"
on public.trips for delete
using (auth.uid() = user_id);
