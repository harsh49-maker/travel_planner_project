import json
import os
from datetime import date, timedelta
from typing import List, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv()

app = FastAPI(
    title="Roamly Travel Planner API",
    description="Create personalized day-by-day travel itineraries.",
    version="1.0.0",
)

frontend_origin = os.getenv("FRONTEND_ORIGIN", "http://localhost:5173")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[frontend_origin, "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class TripRequest(BaseModel):
    destination: str = Field(min_length=2, max_length=120)
    start_date: Optional[date] = None
    duration_days: int = Field(default=3, ge=1, le=14)
    budget: int = Field(default=12000, ge=0, le=10_000_000)
    travel_style: str = "Balanced"
    travellers: str = "Solo traveler"
    interests: List[str] = Field(default_factory=lambda: ["Sightseeing", "Food"])


class Activity(BaseModel):
    time: str
    title: str
    description: str
    category: str = "Sightseeing"
    estimated_cost: int = 0


class ItineraryDay(BaseModel):
    day: int
    title: str
    activities: List[Activity]


class TripResponse(BaseModel):
    destination: str
    start_date: Optional[str]
    duration_days: int
    budget: int
    travel_style: str
    travellers: str
    summary: str
    estimated_total: int
    days: List[ItineraryDay]
    tips: List[str]
    generated_by: str


def fallback_itinerary(req: TripRequest) -> TripResponse:
    date_label = req.start_date.isoformat() if req.start_date else None
    day_templates = [
        ("Arrival and local highlights", [
            ("09:00", "Breakfast at a local café", "Start the day with a relaxed breakfast and a local favourite.", "Food", 500),
            ("10:30", "Explore a signature attraction", "Visit a well-known landmark and allow time to explore at your own pace.", "Sightseeing", 800),
            ("13:00", "Regional lunch stop", "Try a popular regional dish at a casual restaurant.", "Food", 700),
            ("15:30", "Neighbourhood walk", "Explore nearby streets, shops, and photo spots.", "Culture", 300),
            ("18:00", "Sunset viewpoint", "Finish the day with a scenic stop before dinner.", "Nature", 300),
        ]),
        ("Culture and hidden gems", [
            ("09:00", "Slow morning coffee", "Enjoy a café stop before the day gets busy.", "Food", 400),
            ("10:30", "Culture and history", "Visit a museum, heritage site, or local cultural attraction.", "Culture", 700),
            ("13:00", "Local lunch", "Take a break and sample another regional speciality.", "Food", 700),
            ("15:00", "Markets and independent shops", "Browse local crafts and pick up a small keepsake.", "Shopping", 500),
            ("17:30", "Relaxed evening stroll", "Leave some time to wander and discover a favourite spot.", "Nature", 200),
        ]),
        ("A relaxed final day", [
            ("09:00", "Breakfast with a view", "Keep the morning unhurried and enjoy one last local breakfast.", "Food", 500),
            ("10:30", "One final attraction", "Choose a nearby highlight that fits your remaining time.", "Sightseeing", 700),
            ("12:30", "Last local meal", "Enjoy a final regional meal before heading back.", "Food", 600),
            ("14:00", "Departure buffer", "Allow time for check-out and transport.", "Transport", 500),
        ]),
    ]

    days = []
    for i in range(req.duration_days):
        title, rows = day_templates[i % len(day_templates)]
        activities = [
            Activity(time=t, title=name, description=desc, category=cat, estimated_cost=cost)
            for t, name, desc, cat, cost in rows
        ]
        days.append(ItineraryDay(day=i + 1, title=title, activities=activities))

    estimated = min(req.budget, sum(a.estimated_cost for d in days for a in d.activities)) if req.budget else sum(a.estimated_cost for d in days for a in d.activities)
    return TripResponse(
        destination=req.destination,
        start_date=date_label,
        duration_days=req.duration_days,
        budget=req.budget,
        travel_style=req.travel_style,
        travellers=req.travellers,
        summary=f"A {req.travel_style.lower()} {req.duration_days}-day plan for {req.destination}, shaped around {', '.join(req.interests) or 'local highlights'}.",
        estimated_total=estimated,
        days=days,
        tips=[
            "Confirm opening hours and ticket requirements before visiting.",
            "Group nearby places together to reduce travel time.",
            "Keep a small buffer in your budget for local transport and unexpected finds.",
        ],
        generated_by="demo-fallback",
    )


def ai_itinerary(req: TripRequest) -> Optional[TripResponse]:
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        return None

    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        prompt = f"""
Create a realistic, helpful travel itinerary as JSON only.
Destination: {req.destination}
Start date: {req.start_date or 'flexible'}
Duration: {req.duration_days} days
Total budget in INR: {req.budget}
Travel style: {req.travel_style}
Travellers: {req.travellers}
Interests: {', '.join(req.interests)}
Avoid claiming live prices, availability, opening hours, or bookings are verified.
Use this JSON structure:
{{
 "summary": "short summary",
 "estimated_total": 0,
 "days": [
   {{"day": 1, "title": "Day theme", "activities": [
     {{"time":"09:00", "title":"Activity", "description":"Short details", "category":"Sightseeing", "estimated_cost":500}}
   ]}}
 ],
 "tips": ["tip 1", "tip 2"]
}}
Include 3-5 activities per day and estimated costs in INR. Keep the plan within the budget where practical.
"""
        response = client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            messages=[
                {"role": "system", "content": "You are a thoughtful travel itinerary assistant. Return valid JSON only."},
                {"role": "user", "content": prompt},
            ],
            response_format={"type": "json_object"},
            temperature=0.7,
        )
        payload = json.loads(response.choices[0].message.content or "{}")
        return TripResponse(
            destination=req.destination,
            start_date=req.start_date.isoformat() if req.start_date else None,
            duration_days=req.duration_days,
            budget=req.budget,
            travel_style=req.travel_style,
            travellers=req.travellers,
            summary=payload.get("summary", f"A personalized itinerary for {req.destination}."),
            estimated_total=int(payload.get("estimated_total", req.budget)),
            days=payload.get("days", []),
            tips=payload.get("tips", []),
            generated_by="ai",
        )
    except Exception as exc:
        # Do not leak credentials or provider details to the client.
        print(f"AI generation failed; using fallback. Error type: {type(exc).__name__}")
        return None


@app.get("/")
def root():
    return {"message": "Roamly Travel Planner API", "docs": "/docs", "status": "ok"}


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/itinerary", response_model=TripResponse)
def create_itinerary(request: TripRequest):
    result = ai_itinerary(request)
    return result if result is not None else fallback_itinerary(request)
