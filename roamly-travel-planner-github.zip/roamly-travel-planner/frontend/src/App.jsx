import { useMemo, useState } from "react";
import {
  Compass, MapPin, CalendarDays, Wallet, Clock3, Heart, Sparkles,
  House, Bookmark, Search, Settings, CircleHelp, RefreshCw, ArrowUpRight,
  Coffee, Castle, Utensils, Trees, ShoppingBag, Sun, Menu, X, Check
} from "lucide-react";

const API = import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000";
const interestsList = ["Sightseeing", "Food", "Nature", "Adventure", "Shopping", "Culture"];
const fallbackDays = [
  { day: 1, title: "Palaces, lakes & old-city charm", activities: [
    { time: "09:00", title: "Breakfast by the lake", description: "Start slow with chai and a local breakfast.", category: "Food", estimated_cost: 400 },
    { time: "10:30", title: "City Palace", description: "Explore royal courtyards and sweeping lake views.", category: "Sightseeing", estimated_cost: 800 },
    { time: "13:00", title: "Lunch in the old city", description: "Try a Rajasthani thali at a relaxed local restaurant.", category: "Food", estimated_cost: 700 },
    { time: "16:00", title: "Lake Pichola boat ride", description: "See the palaces glow from the water.", category: "Nature", estimated_cost: 900 },
    { time: "18:00", title: "Ambrai Ghat at sunset", description: "A peaceful lakeside walk and golden-hour photos.", category: "Nature", estimated_cost: 200 },
  ]},
  { day: 2, title: "Art, gardens & hidden lanes", activities: [
    { time: "09:00", title: "Jagdish Temple", description: "Admire the intricate stone carvings in the old city.", category: "Culture", estimated_cost: 0 },
    { time: "10:30", title: "Bagore Ki Haveli", description: "Discover local art, history and traditional architecture.", category: "Culture", estimated_cost: 300 },
    { time: "13:00", title: "Lunch at a rooftop café", description: "Take a break with city views and regional flavours.", category: "Food", estimated_cost: 700 },
    { time: "15:00", title: "Saheliyon-ki-Bari", description: "Wander through fountains and leafy garden paths.", category: "Nature", estimated_cost: 150 },
    { time: "17:30", title: "Hathi Pol market", description: "Browse miniature paintings, textiles and handmade finds.", category: "Shopping", estimated_cost: 500 },
  ]},
  { day: 3, title: "A slow morning & one last view", activities: [
    { time: "09:00", title: "Coffee with a view", description: "Enjoy an unhurried breakfast overlooking the rooftops.", category: "Food", estimated_cost: 450 },
    { time: "10:30", title: "Sajjangarh viewpoint", description: "Take in wide views of the Aravalli hills.", category: "Nature", estimated_cost: 500 },
    { time: "13:00", title: "Local lunch stop", description: "Sample a final Rajasthani favourite before departure.", category: "Food", estimated_cost: 600 },
    { time: "15:00", title: "Fateh Sagar Lake", description: "Walk the promenade and enjoy the breeze.", category: "Nature", estimated_cost: 100 },
  ]},
];

function formatMoney(value) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value || 0);
}
function formatDate(value) {
  if (!value) return "Dates flexible";
  return new Date(`${value}T12:00:00`).toLocaleDateString("en-IN", { month: "short", day: "numeric", year: "numeric" });
}
function iconFor(category) {
  if (category === "Food") return <Coffee size={17}/>;
  if (category === "Culture") return <Castle size={17}/>;
  if (category === "Nature") return <Trees size={17}/>;
  if (category === "Shopping") return <ShoppingBag size={17}/>;
  if (category === "Transport") return <Compass size={17}/>;
  return <MapPin size={17}/>;
}

export default function App() {
  const [page, setPage] = useState("Overview");
  const [destination, setDestination] = useState("Udaipur, Rajasthan");
  const [startDate, setStartDate] = useState("2026-11-14");
  const [duration, setDuration] = useState(3);
  const [style, setStyle] = useState("Balanced");
  const [travellers, setTravellers] = useState("Couple");
  const [budget, setBudget] = useState(12000);
  const [interests, setInterests] = useState(["Sightseeing", "Food"]);
  const [days, setDays] = useState(fallbackDays);
  const [activeDay, setActiveDay] = useState(1);
  const [savedTrips, setSavedTrips] = useState(() => {
    try { return JSON.parse(localStorage.getItem("roamly-saved-trips") || "[]"); } catch { return []; }
  });
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);

  const trip = useMemo(() => ({
    destination, start_date: startDate || null, duration_days: Number(duration), budget: Number(budget),
    travel_style: style, travellers, interests
  }), [destination, startDate, duration, budget, style, travellers, interests]);

  const toggleInterest = (name) => setInterests(old => old.includes(name) ? old.filter(x => x !== name) : [...old, name]);
  const flash = (message) => { setNotice(message); window.setTimeout(() => setNotice(""), 2800); };

  async function generateTrip() {
    setLoading(true);
    try {
      const response = await fetch(`${API}/api/itinerary`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(trip)
      });
      if (!response.ok) throw new Error("API unavailable");
      const data = await response.json();
      setDays(data.days?.length ? data.days : fallbackDays);
      setActiveDay(1);
      flash(data.generated_by === "ai" ? "Your AI itinerary is ready ✨" : "Your itinerary is ready ✨");
    } catch {
      const matched = fallbackDays.slice(0, Number(duration));
      setDays(Array.from({ length: Number(duration) }, (_, i) => matched[i] || {
        day: i + 1, title: ["Explore local favourites", "Culture and hidden gems", "A relaxed final day"][i % 3],
        activities: fallbackDays[i % 3].activities
      }));
      setActiveDay(1);
      flash("Demo itinerary ready. Start the API for backend generation.");
    } finally { setLoading(false); }
  }

  function saveTrip() {
    const item = { ...trip, id: Date.now(), days, savedAt: new Date().toISOString() };
    const next = [item, ...savedTrips.filter(t => t.destination !== destination)];
    setSavedTrips(next);
    localStorage.setItem("roamly-saved-trips", JSON.stringify(next));
    flash("Trip saved to your collection ♡");
  }

  function loadTrip(item) {
    setDestination(item.destination); setStartDate(item.start_date || ""); setDuration(item.duration_days);
    setBudget(item.budget); setStyle(item.travel_style); setTravellers(item.travellers);
    setInterests(item.interests || []); setDays(item.days || fallbackDays); setActiveDay(1); setPage("Overview");
  }

  const currentDay = days.find(d => d.day === activeDay) || days[0] || fallbackDays[0];
  const destinationName = destination.trim() || "Your destination";
  const nav = [
    { label: "Overview", icon: <House size={17}/> },
    { label: "AI Trip Builder", icon: <Sparkles size={17}/> },
    { label: "Saved Trips", icon: <Bookmark size={17}/> },
    { label: "Discover", icon: <Compass size={17}/> },
  ];
  function go(label) { setPage(label === "AI Trip Builder" ? "Overview" : label); setMobileMenu(false); }

  return <div className="app-shell">
    <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
      <div className="brand"><span className="brand-mark">✳</span> roamly<span className="brand-dot">.</span></div>
      <div className="nav-label">WORKSPACE</div>
      <nav>{nav.map(item => <button key={item.label} className={`nav-item ${(page === item.label || (item.label === "AI Trip Builder" && page === "Overview")) ? "active" : ""}`} onClick={() => go(item.label)}>{item.icon}<span>{item.label}</span>{item.label === "Saved Trips" && savedTrips.length > 0 && <em>{savedTrips.length}</em>}</button>)}</nav>
      <div className="nav-label account-label">YOUR ACCOUNT</div>
      <button className="nav-item" onClick={() => flash("Settings are ready for the demo.")}><Settings size={17}/><span>Settings</span></button>
      <button className="nav-item" onClick={() => flash("Help centre opened for the demo.")}><CircleHelp size={17}/><span>Help centre</span></button>
      <div className="sidebar-promo"><div className="promo-icon">🌿</div><b>Your next story awaits.</b><p>Great trips start with a little inspiration. Let AI do the planning.</p><button onClick={() => go("Overview")}>Plan a new trip ↗</button></div>
    </aside>

    <main className="main-area">
      <header className="topbar">
        <button className="mobile-menu" onClick={() => setMobileMenu(v => !v)}>{mobileMenu ? <X size={19}/> : <Menu size={19}/>}</button>
        <div className="breadcrumbs">Workspace <span>/</span> <b>{page}</b></div>
        <div className="profile"><span>Good afternoon!</span><div className="avatar">T</div><b>Traveler</b></div>
      </header>

      <div className="content">
        {page === "Overview" && <>
          <section className="hero">
            <div><div className="eyebrow"><Sparkles size={12}/> YOUR PERSONAL TRAVEL COPILOT</div><h1>Make room for <span>wonder.</span></h1><p>Dream it. Plan it. Go live it. Your next adventure starts here.</p></div>
            <div className="date-pill"><Clock3 size={15}/> Your travel dashboard</div>
          </section>
          <section className="stats-grid">
            <Stat icon="🧳" label="Trips planned" value={String(Math.max(1, savedTrips.length)).padStart(2, "0")} foot="Your journey collection"/>
            <Stat icon="📍" label="Places to explore" value={String(Number(duration) * 3 + 1).padStart(2, "0")} foot="Curated for your interests"/>
            <Stat icon="💳" label="Budget planned" value={formatMoney(budget)} foot="Estimated trip budget"/>
            <Stat icon="✦" label="Planning time saved" value="4.5 hrs" foot="With smart planning"/>
          </section>

          <section className="workspace-grid">
            <div className="panel builder-panel">
              <div className="panel-heading"><div><h2>Build your next trip</h2><p>A few details. A whole lot of possibility.</p></div><span className="step-label">STEP 01 / 03</span></div>
              <div className="form-content">
                <Field label="Where do you want to go?"><input value={destination} onChange={e => setDestination(e.target.value)} placeholder="Try Goa, Jaipur, Manali..."/></Field>
                <div className="two-cols">
                  <Field label="Departure date"><input type="date" value={startDate} onChange={e => setStartDate(e.target.value)}/></Field>
                  <Field label="Duration"><select value={duration} onChange={e => setDuration(Number(e.target.value))}>{[2,3,4,5,7,10,14].map(n => <option key={n} value={n}>{n} days</option>)}</select></Field>
                </div>
                <div className="two-cols">
                  <Field label="Travel style"><select value={style} onChange={e => setStyle(e.target.value)}>{["Balanced","Relaxed","Adventure","Luxury","Culture & history"].map(x => <option key={x}>{x}</option>)}</select></Field>
                  <Field label="Travellers"><select value={travellers} onChange={e => setTravellers(e.target.value)}>{["Solo traveler","Couple","Friends group","Family"].map(x => <option key={x}>{x}</option>)}</select></Field>
                </div>
                <div className="field"><label>What are you in the mood for?</label><div className="chips">{interestsList.map((name, i) => <button key={name} className={`chip ${interests.includes(name) ? "selected" : ""}`} onClick={() => toggleInterest(name)}>{["🏛","🍜","🌿","🧗","🛍","🎭"][i]} {name}</button>)}</div></div>
                <div className="field"><div className="budget-label"><label>Total budget</label><b>{formatMoney(budget)}</b></div><input className="range" type="range" min="3000" max="100000" step="1000" value={budget} onChange={e => setBudget(Number(e.target.value))}/><div className="range-ends"><span>₹3,000</span><span>₹1,00,000</span></div></div>
                <button className="primary-btn" onClick={generateTrip} disabled={loading}><Sparkles size={16}/>{loading ? "Generating your itinerary..." : "Generate my itinerary"}<ArrowUpRight size={16}/></button>
                <div className="microcopy">Personalized suggestions · You stay in control</div>
              </div>
            </div>

            <div className="panel itinerary-panel">
              <div className="cover-art"><div className="cover-sun"/><div className="cover-hills hill-back"/><div className="cover-hills hill-front"/><div className="cover-buttons"><button title="Save trip" onClick={saveTrip}><Heart size={16}/></button><button title="Regenerate itinerary" onClick={generateTrip}><RefreshCw size={16}/></button></div><div className="cover-copy"><span>{travellers.toUpperCase()} · YOUR NEXT ESCAPE</span><h2>{destinationName}</h2><p>The best moments are the ones you plan for less.</p></div></div>
              <div className="trip-meta">
                <Meta icon={<CalendarDays size={15}/>} label="DATES" value={`${formatDate(startDate)} · ${duration} days`}/>
                <Meta icon={<Compass size={15}/>} label="TRIP STYLE" value={`${style} · ${travellers}`}/>
                <Meta icon={<Wallet size={15}/>} label="EST. BUDGET" value={`${formatMoney(budget)} / trip`} green/>
              </div>
              <div className="itinerary-body">
                <div className="itinerary-heading"><h3>Your day-by-day plan</h3><span className="ai-tag"><Sparkles size={12}/> Smart itinerary</span></div>
                <div className="day-tabs">{Array.from({length: Number(duration)}, (_, i) => <button key={i} className={activeDay === i + 1 ? "active" : ""} onClick={() => setActiveDay(i + 1)}>Day {i + 1}</button>)}</div>
                {currentDay && <div className="day-block"><div className="day-marker"><span>DAY</span><b>{currentDay.day}</b></div><div className="day-main"><div className="day-title"><h4>{currentDay.title}</h4><span>{activeDay === 1 ? "A little adventure" : activeDay === duration ? "Take it slow" : "Find your rhythm"}</span></div>{currentDay.activities?.map((activity, i) => <div className="activity" key={`${activity.title}-${i}`}><div className="activity-time">{activity.time}</div><div className="activity-copy"><b>{activity.title}</b><p>{activity.description}</p></div><div className="activity-icon">{iconFor(activity.category)}</div></div>)}</div></div>}
              </div>
              <div className="local-tip"><Sparkles size={17}/><div><b>A little local wisdom</b><p>Leave room for an unexpected favourite. Check opening hours and transport details before heading out.</p></div></div>
            </div>
          </section>
        </>}

        {page === "Saved Trips" && <section className="page-section"><div className="hero"><div><div className="eyebrow">YOUR COLLECTION</div><h1>Saved <span>adventures.</span></h1><p>All the places you’re dreaming about, in one spot.</p></div><button className="primary-btn compact" onClick={() => setPage("Overview")}>＋ Plan a trip</button></div><div className="panel"><div className="panel-heading"><div><h2>Your saved trips</h2><p>Keep your favourite plans close at hand.</p></div></div>{savedTrips.length ? savedTrips.map(item => <div className="saved-row" key={item.id}><div className="saved-thumb">🏞️</div><div className="saved-copy"><b>{item.destination}</b><p>{item.duration_days} days · {item.travellers} · {formatMoney(item.budget)} estimated</p></div><button className="secondary-btn" onClick={() => loadTrip(item)}>View plan</button><button className="icon-btn" title="Remove saved trip" onClick={() => { const next = savedTrips.filter(t => t.id !== item.id); setSavedTrips(next); localStorage.setItem("roamly-saved-trips", JSON.stringify(next)); }}>×</button></div>) : <div className="empty-state"><Bookmark size={28}/><b>No saved trips yet</b><p>Generate an itinerary and tap the heart to save it here.</p><button className="secondary-btn" onClick={() => setPage("Overview")}>Build a trip</button></div>}</div></section>}

        {page === "Discover" && <section className="page-section"><div className="hero"><div><div className="eyebrow">FIND YOUR NEXT FAVOURITE</div><h1>Made for the <span>curious.</span></h1><p>A little inspiration for wherever your mind wanders.</p></div></div><div className="destination-grid">{[
          {name:"Goa",emoji:"🌊",desc:"Beach days, colourful cafés & sunsets.",colour:"sea"},
          {name:"Jaipur",emoji:"🕌",desc:"Royal forts, pink streets & local flavours.",colour:"pink"},
          {name:"Manali",emoji:"🏔️",desc:"Mountain air, pine trails & cosy cafés.",colour:"mountain"},
          {name:"Rishikesh",emoji:"🌿",desc:"River views, yoga & outdoor adventures.",colour:"forest"}
        ].map(place => <button className="destination-card" key={place.name} onClick={() => { setDestination(place.name); setPage("Overview"); }}><div className={`destination-art ${place.colour}`}>{place.emoji}</div><div className="destination-copy"><h3>{place.name}</h3><p>{place.desc}</p><span>Plan this trip ↗</span></div></button>)}</div></section>}
      </div>
    </main>
    {notice && <div className="toast"><Check size={16}/>{notice}</div>}
  </div>;
}

function Stat({ icon, label, value, foot }) { return <div className="stat-card"><div className="stat-top"><span>{label}</span><span className="stat-emoji">{icon}</span></div><strong>{value}</strong><small>{foot}</small></div>; }
function Field({ label, children }) { return <div className="field"><label>{label}</label>{children}</div>; }
function Meta({ icon, label, value, green }) { return <div className="meta-item"><div>{icon}<span>{label}</span></div><b className={green ? "green-text" : ""}>{value}</b></div>; }
